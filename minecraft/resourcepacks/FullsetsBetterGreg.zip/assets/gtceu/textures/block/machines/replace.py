import os

parent_folder = os.path.dirname(os.path.realpath(__file__))

for root, dirs, files in os.walk(parent_folder):
    for file in files:
        if "GLOW" in file:
            old_file_path = os.path.join(root, file)

            new_file_name = file.replace("GLOW", "EMISSIVE")
            new_file_path = os.path.join(root, new_file_name)
            
            os.rename(old_file_path, new_file_path)
            print(f'Renamed: "{old_file_path}" to "{new_file_path}"')